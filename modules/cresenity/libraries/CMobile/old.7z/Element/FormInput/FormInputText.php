<?php

class CMobile_Element_FormInput_FormInputText extends CMobile_Element_FormInput {

    protected $vk;
    protected $vk_opt;
    protected $placeholder;
    protected $bootstrap;
    protected $label_float;

    public function __construct($id) {
        parent::__construct($id);

        $this->type = "text";
        $this->vk = false;
        $this->placeholder = "";
        $default_option = array(
            'layout' => 'qwerty',
            'restrictInput' => 'true',
            'preventPaste' => 'true',
            'autoAccept' => 'true',
        );
        $this->bootstrap = ccfg::get('bootstrap');
        if (strlen($this->bootstrap) == 0) {
            $this->bootstrap = '2';
        }
        $this->label_float = true;
        $this->vk_opt = $default_option;
    }

    /**
     * 
     * @param type $id
     * @return \CFormInputText
     */
    public static function factory($id = '') {
        return new CMobile_Element_FormInput_FormInputText($id);
    }

    public function set_vk($bool) {
        $this->vk = $bool;
        return $this;
    }

    public function set_placeholder($placeholder) {
        $this->placeholder = $placeholder;
        return $this;
    }

    public function disable_label_float() {
        $this->label_float = false;
        return $this;
    }

    public function set_vk_opt($option) {
        $this->vk_opt = array_merge($this->vk_opt, $option);
        return $this;
    }

    public function set_name($name){
        $this->name = $name; return $this;
    }
    
	protected function html_attr() {
		$html_attr = parent::html_attr();
		$placeholder = "";
		
		if ($this->placeholder)
			$placeholder = ' placeholder="'.$this->placeholder.'"';
				
		// $html_attr .= $placeholder;
		return $html_attr;
	}
	
    public function html($indent = 0) {
        $html = new CStringBuilder();
        $html->set_indent($indent);

		$this->add_class('input-unstyled');
        $this->add_class('form-control');
        
		$this->add_class( $this->validation->validation_class());

		$html_attr = $this->html_attr();
        $html->appendln('<input type="text" '.$html_attr  .'>')->br();
        $html->appendln('<p class="help-block">' . $this->placeholder . '</p>')->br();
        return $html->text();
    }

    public function js($indent = 0) {
        $js = new CStringBuilder();
        $js->set_indent($indent);
        $js->append(parent::js());
        if ($this->vk) {
            $js->append("$('#" . $this->id . "').keyboard(" . json_encode($this->vk_opt) . ");")->br();
        }


        return $js->text();
    }

}