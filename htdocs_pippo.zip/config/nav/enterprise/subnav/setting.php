<?php
return array(
		array(
			"name"=>"access",
			"label"=>"Access",
			"subnav"=>array(
				array(
					"name"=>"roles",
					"label"=>"Roles",
					"controller"=>"roles",
					"method"=>"index",
					'action'=>array(
						
						array(
							'name'=>'add_roles',
							'label'=>'Add',
							'controller'=>'roles',
							'method'=>'add',
						),
						array(
							'name'=>'edit_roles',
							'label'=>'Edit',
							'controller'=>'roles',
							'method'=>'edit',
						),
						array(
							'name'=>'delete_roles',
							'label'=>'Delete',
							'controller'=>'roles',
							'method'=>'delete',
						),
						array(
							'name'=>'order_roles',
							'label'=>'Change Order',
							'controller'=>'roles',
							'method'=>'ordering',
						),
					),//end action roles
				),
				array(
					"name"=>"users",
					"label"=>"Users",
					"controller"=>"users",
					"method"=>"index",
					'action'=>array(
						array(
							'name'=>'detail_users',
							'label'=>'Detail',
							'controller'=>'users',
							'method'=>'detail',
						),
						array(
							'name'=>'add_users',
							'label'=>'Add',
							'controller'=>'users',
							'method'=>'add',
						),
						array(
							'name'=>'edit_users',
							'label'=>'Edit',
							'controller'=>'users',
							'method'=>'edit',
						),
						array(
							'name'=>'delete_users',
							'label'=>'Delete',
							'controller'=>'users',
							'method'=>'delete',
						),
					),//end action users
				),
				array(
					"name"=>"user_permission",
					"label"=>"Users Permission",
					"controller"=>"user_permission",
					"method"=>"index",	
				),
			),//end subnav access
		),
		array(
			"name"=>"store_warehouse",
			"label"=>"Store Warehouse",
			"controller"=>"store_warehouse",
			"method"=>"index",
			
			"requirements"=>array(
				"have_store"=>true,
			),
		),
		array(
			"name"=>"warehouse",
			"label"=>"Warehouse",
			"controller"=>"warehouse",
			"method"=>"index",
			'action'=>array(
				array(
					'name'=>'add_warehouse',
					'label'=>'Add',
					'controller'=>'warehouse',
					'method'=>'add',
				),
				array(
					'name'=>'edit_warehouse',
					'label'=>'Edit',
					'controller'=>'warehouse',
					'method'=>'edit',
				),
				array(
					'name'=>'delete_warehouse',
					'label'=>'Delete',
					'controller'=>'warehouse',
					'method'=>'delete',
				),
			),//end action warehouse
			"requirements"=>array(
				"have_warehouse"=>true,
			),
		),
		
		array(
			"name"=>"bank",
			"label"=>"Bank",
			"controller"=>"bank",
			"method"=>"index",
			'action'=>array(
				array(
					'name'=>'add_bank',
					'label'=>'Add',
					'controller'=>'bank',
					'method'=>'add',
				),
				array(
					'name'=>'edit_bank',
					'label'=>'Edit',
					'controller'=>'bank',
					'method'=>'edit',
				),
				array(
					'name'=>'edit_accounting_bank',
					'label'=>'Edit Accounting',
					'controller'=>'bank',
					'method'=>'edit_accounting',
				),
				array(
					'name'=>'delete_bank',
					'label'=>'Delete',
					'controller'=>'bank',
					'method'=>'delete',
				),
			),//end action bank
		),
		array(
			"name"=>"payment_type",
			"label"=>"Payment Type",
			"controller"=>"payment_type",
			"method"=>"index",
			'action'=>array(
				array(
					'name'=>'edit_accounting_payment_type',
					'label'=>'Edit Accounting',
					'controller'=>'payment_type',
					'method'=>'edit_accounting',
				),
				
			),//end action bank
		),
		array(
			"name"=>"change_hpp",
			"label"=>"Change Hpp",
			"controller"=>"change_hpp",
			"method"=>"index",
		),
		array(
			"name"=>"org_setting",
			"label"=>"Org Setting",
			"controller"=>"org_setting",
			"method"=>"index",
		),
	);