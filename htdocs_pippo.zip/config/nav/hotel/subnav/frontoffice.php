<?php
return array(
	array(
		"name"=>"hotel_timeline",
		"label"=>"Timeline",
		"controller"=>"hotel_timeline",
		"method"=>"index",
		
	),
	array(
		"name"=>"hotel_checkin",
		"label"=>"Check In",
		"controller"=>"hotel_checkin",
		"method"=>"index",
		
	),
	array(
		"name"=>"hotel_reservation",
		"label"=>"Reservation",
		"controller"=>"hotel_reservation",
		"method"=>"index",
		
	),
	
	
);
