<?php
return array(
	array(
		"name"=>"analyze_site",
		"label"=>"Site Analyze",
		"controller"=>"analyze_site",
		"method"=>"index",
		
	),
	
);