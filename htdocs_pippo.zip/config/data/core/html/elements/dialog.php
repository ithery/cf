<?php
return array (
	"description"=>"Defines a dialog box or window",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		"open"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies that the dialog element is active and that the user can interact with it"
		
		),
		
	),
);
		