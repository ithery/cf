<?php
return array (
	"description"=>"Defines a variable",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		