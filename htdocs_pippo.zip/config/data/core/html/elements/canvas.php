<?php
return array (
	"description"=>"Used to draw graphics, on the fly, via scripting (usually JavaScript)",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		"height"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies the height of the canvas"
		),
		"width"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies the width of the canvas"
		
		),
	),
	
); 