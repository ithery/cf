<?php
return array (
	"description"=>"Defines HTML headings",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"align"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the alignment of a heading"
			
		),
	),
	
); 