<?php
return array (
	"description"=>"Defines a client-side image-map",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"name"=>array(
			"html5"=>false,
			"html5_support"=>true,
			"description"=>"Required. Specifies the name of an image-map"
		
		
		
		),
	),
	
); 