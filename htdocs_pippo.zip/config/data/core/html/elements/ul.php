<?php
return array (
	"description"=>"Defines an unordered list",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"compact"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies that the list should render smaller than normal"
		),
		"type"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the kind of marker to use in the list"
			
		),
	),
);	

		