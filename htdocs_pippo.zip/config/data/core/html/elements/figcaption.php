<?php
return array (
	"description"=>"Defines a caption for a <figure> element",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
		
		
		
		
	),
	
); 