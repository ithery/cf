<?php
return array (
	"description"=>"Defines subscripted text",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		