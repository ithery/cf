<?php
return array (
	"description"=>"Defines a part of text in an alternate voice or mood",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 