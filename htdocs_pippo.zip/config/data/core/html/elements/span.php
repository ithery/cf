<?php
return array (
	"description"=>"Defines a section in a document",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
	),
);	
		