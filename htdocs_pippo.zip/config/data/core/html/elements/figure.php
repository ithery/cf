<?php
return array (
	"description"=>"Specifies self-contained content",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
		
		
		
		
	),
	
); 