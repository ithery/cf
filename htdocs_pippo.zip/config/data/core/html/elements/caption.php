<?php
return array (
	"description"=>"Defines a table caption",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"align"=>array(
			"html5"=>true,
			"html5_support"=>false,
			"description"=>"Defines the alignment of the caption"
		
		
		),
	),
	
); 