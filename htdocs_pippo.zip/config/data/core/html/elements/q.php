<?php
return array (
	"description"=>"Defines a short quotation",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"cite"=>array(
			"html5"=>false,
			"html5_support"=>true,
			"description"=>"Specifies the source URL of the quote"
		
		
		),
		
	),
);	
		