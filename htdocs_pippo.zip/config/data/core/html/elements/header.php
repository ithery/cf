<?php
return array (
	"description"=>"Defines a header for a document or section",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
				
		),

	
); 