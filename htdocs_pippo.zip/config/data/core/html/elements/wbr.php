<?php
return array (
	"description"=>"Defines a possible line-break",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		