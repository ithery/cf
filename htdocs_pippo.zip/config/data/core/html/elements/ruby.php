<?php
return array (
	"description"=>"Defines a ruby annotation (for East Asian typography)",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
	),
);	
		