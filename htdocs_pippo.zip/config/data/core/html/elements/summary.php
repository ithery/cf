<?php
return array (
	"description"=>"Defines a visible heading for a <details> element",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		