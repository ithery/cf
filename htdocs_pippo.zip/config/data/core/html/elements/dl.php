<?php
return array (
	"description"=>"Defines a description list",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 