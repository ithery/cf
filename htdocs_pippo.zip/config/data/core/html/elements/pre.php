<?php
return array (
	"description"=>"Defines preformatted text",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"width"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the maximum number of characters per line"
		
		
		),
		
	),
);	
		