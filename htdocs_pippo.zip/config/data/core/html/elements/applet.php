<?php
return array (
	"description"=>"Defines an embedded applet",
	"html5"=>false,
	"html5_support"=>false,
	"attr"=>array(
		
		
		),

	
); 