<?php
return array (
	"description"=>"Defines a paragraph",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"align"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies that an option-group should be disabled"
		
		
		),
		
	),
);	
		