<?php
return array (
	"description"=>"Defines an abbreviation",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
	),
	
); 