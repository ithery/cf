<?php
return array (
	"description"=>"Defines sample output from a computer program",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
	),
);	
		