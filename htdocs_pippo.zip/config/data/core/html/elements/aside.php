<?php
return array (
	"description"=>"Defines content aside from the page content",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 