<?php
return array (
	"description"=>"Defines font, color, and size for text",
	"html5"=>false,
	"html5_support"=>false,
	"attr"=>array(
		"color"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the color of text"
		),
		"face"=>array(	
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the font of text"
		),
		"size"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the size of text"
		
		
		
		
		),
	),
	
); 