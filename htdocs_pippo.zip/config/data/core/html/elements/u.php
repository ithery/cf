<?php
return array (
	"description"=>"Defines text that should be stylistically different from normal text",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		