<?php
return array (
	"description"=>"Defines an acronym",
	"html5"=>false,
	"html5_support"=>false,
	"attr"=>array(
		
	),
	
); 