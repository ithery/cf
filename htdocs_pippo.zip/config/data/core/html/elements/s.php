<?php
return array (
	"description"=>"Defines text that is no longer correct",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"
		
	),
);	
		