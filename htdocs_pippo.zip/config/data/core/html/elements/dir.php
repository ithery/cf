<?php
return array (
	"description"=>"Defines a directory list",
	"html5"=>false,
	"html5_support"=>false,
	"attr"=>array(
		"compact"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies that the list should render smaller than normal"
		
		),
		
	),
);	
		