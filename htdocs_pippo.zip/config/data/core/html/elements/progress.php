<?php
return array (
	"description"=>"Defines a parameter for an object",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		"max"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies how much work the task requires in total"
		),
		"value"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies how much of the task has been completed"
		
		),
		
	),
);	
		