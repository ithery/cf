<?php
return array (
	"description"=>"Defines a piece of computer code",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 