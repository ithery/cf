<?php


$config["cwidget"]=array(
	array(
		"name"=>"transaction_count_graph",
		"label"=>"Transaction Count Graph",
		"size"=>12,
	),
	array(
		"name"=>"transaction_amount_graph",
		"label"=>"Transaction Amount Graph",
		"size"=>12,
	),
	
	array(
        "name"=>"sales_due_date_reminder",
        "label"=>"Sales Due Date Reminder",
        "nopadding"=>true,
		"size"=>6,
    	"scroll"=>true,
    ),
   array(
        "name"=>"purchase_due_date_reminder",
        "label"=>"Purchase Due Date Reminder",
        "nopadding"=>true,
		"size"=>6,
    	"scroll"=>true,
    ),
    array(
        "name"=>"sales_giro_reminder",
        "label"=>"Sales Giro Reminder",
        "nopadding"=>true,
		"size"=>6,
    	"scroll"=>true,
    ),
    array(
        "name"=>"purchase_giro_reminder",
        "label"=>"Purchase Giro Reminder",
        "nopadding"=>true,
		"size"=>6,
    	"scroll"=>true,
    )
);

