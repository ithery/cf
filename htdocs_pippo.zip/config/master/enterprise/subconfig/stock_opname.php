<?php

$stock_opname = array(
	
	
);