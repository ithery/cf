<?php

$warehouse = array(
	array(
		"name"=>"have_warehouse",
		"label"=>"Have Warehouse",
		"default"=>false,
		"type"=>"checkbox",
	),
	
);