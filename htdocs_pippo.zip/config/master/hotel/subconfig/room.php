<?php

$room = array(
	array(
		"name"=>"have_room_building",
		"label"=>"Have Room Building",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_room_floor",
		"label"=>"Have Room Floor",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_room_type",
		"label"=>"Have Room Type",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_room_amenities",
		"label"=>"Have Room Amenities",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_rate_plan",
		"label"=>"Have Rate Plan",
		"default"=>false,
		"type"=>"checkbox",
	),
	
);