<?php

return array(
	"org_id"=>16,
	"org_code"=>"tiketpasti",
	"org_name"=>"TIKETPASTI",
	
);

