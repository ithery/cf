<?php

return array(
	"org_id"=>2,
	"org_code"=>"torstravel",
	"org_name"=>"TORS TRAVEL",
	
);

