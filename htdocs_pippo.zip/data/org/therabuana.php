<?php

return array(
	"org_id"=>10,
	"org_code"=>"therabuana",
	"org_name"=>"THERABUANA",
);

