<?php

return array(
	"org_id"=>'1003',
	"org_code"=>"suryagita",
	"org_name"=>"Suryagita",
	
);

