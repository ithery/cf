<?php

return array(
	"org_id"=>6001,
	"org_code"=>"bosagnes",
	"org_name"=>"Manandang",
	
);

