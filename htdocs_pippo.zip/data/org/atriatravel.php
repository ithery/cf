<?php
return array(
	"org_id"=>70,
	"org_code"=>"atriatravel",
	"org_name"=>"ANDROMEDA",
);