<?php

return array(
	"org_id"=>4,
	"org_code"=>"telindo",
	"org_name"=>"TELINDO",
	
);

