<?php

return array(
	"org_id"=>12,
	"org_code"=>"sample",
	"org_name"=>"sample",
	
);

