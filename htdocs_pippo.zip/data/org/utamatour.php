<?php

return array(
	"org_id"=>15,
	"org_code"=>"utamatour",
	"org_name"=>"UTAMA TOUR",
	
);

