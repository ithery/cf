<?php

return array(
	"org_id"=>8,
	"org_code"=>"pasopati",
	"org_name"=>"PASOPATI",
	
);

