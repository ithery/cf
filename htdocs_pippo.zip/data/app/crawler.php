<?php 
return array(
	'app_id'=>'10000',
	'code'=>'crawler',
	'name'=>'Crawler',
);