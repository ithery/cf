<?php 
return array(
	'app_id'=>'990',
	'code'=>'adminlastmenit',
	'name'=>'Admin Last Menit',
);