<?php 
return array(
	'app_id'=>'0',
	'code'=>'admin',
	'name'=>'ADMIN APPLICATION',
);