<?php 
return array(
	'app_id'=>'1',
	'code'=>'bosagnes',
	'name'=>'Manandang',
);