<?php 
return array(
	'app_id'=>'101',
	'code'=>'minitors',
	'name'=>'Mini TORS',
);