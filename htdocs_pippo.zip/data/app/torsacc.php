<?php 
return array(
	'app_id'=>'203',
	'code'=>'torsacc',
	'name'=>'TORS Accounting',
);