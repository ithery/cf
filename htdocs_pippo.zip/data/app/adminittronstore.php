<?php 
return array(
	'app_id'=>'1000',
	'code'=>'adminittronstore',
	'name'=>'Admin ITTRON Store',
);