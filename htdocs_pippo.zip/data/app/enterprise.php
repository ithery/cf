<?php 
return array(
	'app_id'=>'1',
	'code'=>'merahdelima',
	'name'=>'Merah Delima',
);