<?php 
return array(
	'app_id'=>'900',
	'code'=>'adminbioto',
	'name'=>'Admin Bioto',
);