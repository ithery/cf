<?php 
return array(
	'app_id'=>'405',
	'code'=>'cmstorsb2c',
	'name'=>'CMS TORSB2C',
);