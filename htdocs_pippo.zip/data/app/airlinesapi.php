<?php 
return array(
	'app_id'=>'75',
	'code'=>'airlinesapi',
	'name'=>'AIRLINES API',
);