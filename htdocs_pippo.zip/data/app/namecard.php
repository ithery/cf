<?php 
return array(
	'app_id'=>'888',
	'code'=>'namecard',
	'name'=>'Name Card',
);