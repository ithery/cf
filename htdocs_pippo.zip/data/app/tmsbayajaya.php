<?php 
return array(
	'app_id'=>'204',
	'code'=>'tmsbayajaya',
	'name'=>'TMS-BAYAJAYA',
);