<?php 
return array(
	'app_id'=>'10010',
	'code'=>'tesis',
	'name'=>'Tesis',
);