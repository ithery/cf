<?php 
return array(
	'app_id'=>'401',
	'code'=>'hrmonline',
	'name'=>'Hrm Online',
);