<?php 
return array(
	'app_id'=>'1002',
	'code'=>'bdc',
	'name'=>'BDC',
);