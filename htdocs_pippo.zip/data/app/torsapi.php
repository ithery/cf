<?php 
return array(
	'app_id'=>'201',
	'code'=>'torsapi',
	'name'=>'TORS API',
);