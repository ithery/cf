<?php 
return array(
	'app_id'=>'301',
	'code'=>'hrm',
	'name'=>'HRM',
);