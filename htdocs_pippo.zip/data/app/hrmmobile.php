<?php 
return array(
	'app_id'=>'402',
	'code'=>'hrmmobile',
	'name'=>'Hrm Mobile',
);