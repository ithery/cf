<?php 
return array(
	'app_id'=>'1090',
	'code'=>'adminnamecard',
	'name'=>'Admin Name Card',
);