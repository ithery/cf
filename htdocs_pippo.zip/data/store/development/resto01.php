<?php

return array(
	"store_id"=>'71',
	"store_code"=>"resto01",
	"store_name"=>"Resto 01",
	
);

