<?php 
return array(
	'app_id'=>'201',
	'app_code'=>'torsapi',
	'org_id'=>'114',
	'org_code'=>'tiketpasti',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'payment.tiketpasti.local',
);