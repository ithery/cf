<?php
return array(
	"app_id"=>'9999',
	"app_code"=>"intern",
	"org_id"=>'',
	"org_code"=>'',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"intern.local",
);
