<?php
return array(
	"app_id"=>'3',
	"app_code"=>"hotel",
	"org_id"=>'7777',
	"org_code"=>"development",
	"store_id"=>'72',
	"store_code"=>'hotel01',
	"domain"=>"hotel.local",
);
