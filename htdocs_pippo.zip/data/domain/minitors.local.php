<?php
return array(
	"app_id"=>'101',
	"app_code"=>"minitors",
	"org_id"=>null,
	"org_code"=>'',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"minitors.local",
);
