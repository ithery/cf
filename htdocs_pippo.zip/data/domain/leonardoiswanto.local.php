<?php 
return array(
	'app_id'=>'888',
	'app_code'=>'namecard',
	'org_id'=>777,
	'org_code'=>"leonardo",
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'leonardoiswanto.local',
        'shared_app_code'=>array(
            "adminnamecard"
        ),
);