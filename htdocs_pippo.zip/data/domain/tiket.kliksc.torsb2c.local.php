<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>'107001',
	'org_code'=>'tiket.kliksc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'tiket.kliksc.torsb2c.local',
);