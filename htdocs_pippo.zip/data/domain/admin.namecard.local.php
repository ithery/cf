<?php
return array(
	"app_id"=>'1090',
	"app_code"=>"adminnamecard",
	"org_id"=>1,
	"org_code"=>"namecard",
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"admin.namecard.local",
        
);
