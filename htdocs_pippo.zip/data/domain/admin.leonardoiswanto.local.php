<?php
return array(
	"app_id"=>'1090',
	"app_code"=>"adminnamecard",
	"org_id"=>777,
	"org_code"=>"leonardo",
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"admin.leonardoiswanto.local",
        
);
