<?php 
return array(
	'app_id'=>'1002',
	'app_code'=>'cmsbdc',
	'org_id'=> 1002,
	'org_code'=>'bdc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'cms.bdc.local',
);