<?php 
return array(
	'app_id'=>'501',
	'app_code'=>'rasasayangticket',
	'org_id'=>15,
	'org_code'=>'b2c',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'rasasayangticket.local',
);