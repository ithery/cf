<?php 
return array(
	'app_id'=>'810',
	'app_code'=>'ittronmall',
	'org_id'=>'1',
	'org_code'=>'ittronmall',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'ittronmall.local',
);