<?php 
return array(
	'app_id'=>'1000',
	'app_code'=>'adminittronstore',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'admin.ittronstore.local',
);