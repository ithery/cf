<?php
return array(
	"app_id"=>'301',
	"app_code"=>"hrm",
	"org_id"=>'1003',
	"org_code"=>'suryagita',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"suryagita.local",
);
