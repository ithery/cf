<?php
return array(
	"app_id"=>'39',
	"app_code"=>"sms",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"sms.local",
);
