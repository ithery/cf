<?php

    return array(
	"app_id"=>'501',
	"app_code"=>"siap",
	"org_id"=>'5001',
	"org_code"=>'siap',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"development.siap.local",
);
