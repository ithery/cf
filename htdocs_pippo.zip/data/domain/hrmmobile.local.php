<?php
return array(
	"app_id"=>'402',
	"app_code"=>"hrmmobile",
	"org_id"=>'4001',
	"org_code"=>'demohrmonline',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"hrmmobile.local",
);
