<?php 
return array(
	'app_id'=>'405',
	'app_code'=>'cmstorsb2c',
	'org_id'=>'107001',
	'org_code'=>'tiket.kliksc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'cms.tiket.kliksc.com',
);