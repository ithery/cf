<?php
return array(
	"app_id"=>'301',
	"app_code"=>"hrm",
	"org_id"=>'1001',
	"org_code"=>'aspra',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"aspra.local",
);
