<?php
return array(
	"app_id"=>'102',
	"app_code"=>"naknan",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"naknan.local",
);
