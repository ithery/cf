<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'3',
	'org_code'=>'travons',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'travons.b2b.local',
);