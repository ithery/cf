<?php 
return array(
	'app_id'=>'405',
	'app_code'=>'cmstorsb2c',
	'org_id'=>16,
	'org_code'=>'tiketpasti',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'cmstiketpasti.local',
);