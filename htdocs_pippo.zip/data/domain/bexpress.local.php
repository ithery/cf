<?php 
return array(
	'app_id'=>'501',
	'app_code'=>'bexpress',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'bexpress.local',
);