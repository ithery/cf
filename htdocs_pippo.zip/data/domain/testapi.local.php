<?php 
return array(
	'app_id'=>'201',
	'app_code'=>'torsapi',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'testapi.local',
);