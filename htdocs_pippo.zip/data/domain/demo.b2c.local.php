<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>'15',
	'org_code'=>'b2c',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'demo.b2c.local',
);