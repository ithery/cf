<?php 
return array(
	'app_id'=>'900',
	'app_code'=>'lastmenit',
	'org_id'=>'1',
	'org_code'=>'lastmenit',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'lastmenit.local',
	'shared_app_code'=>array(
            "lastmenitshare"
        ),
    
);