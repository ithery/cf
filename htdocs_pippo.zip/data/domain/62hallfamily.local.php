<?php 
return array(
	'app_id'=>'800',
	'app_code'=>'62hallfamily',
	'org_id'=>'620001',
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'62hallfamily.local',
	'theme'=>'ittron-62hall',
);