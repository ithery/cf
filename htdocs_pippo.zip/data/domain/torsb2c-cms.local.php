<?php 
return array(
	'app_id'=>'405',
	'app_code'=>'torsb2c-cms',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'torsb2c-cms.local',
);