<?php 
return array(
	'app_id'=>'1001',
	'app_code'=>'bdc',
	'org_id'=> 1001,
	'org_code'=>'bdc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'bdc.local',
);