<?php
return array(
	"app_id"=>'80',
	"app_code"=>"manual",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"manual.local",
);
