<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>'107',
	'org_code'=>'kliksc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'kliksc.torsb2c.local',
);