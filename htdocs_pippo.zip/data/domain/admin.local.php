<?php
return array(
	"app_id"=>'0',
	"app_code"=>"admin",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"admin.local",
);
