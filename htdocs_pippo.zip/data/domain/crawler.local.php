<?php 
return array(
	'app_id'=>'10000',
	'app_code'=>'crawler',
	'org_id'=>null,
	'org_code'=>null,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'crawler.local',
);