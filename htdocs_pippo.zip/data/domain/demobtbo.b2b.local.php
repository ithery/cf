<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'6',
	'org_code'=>'demobtbo',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'demobtbo.b2b.local',
);