<?php 
return array(
	'app_id'=>'10010',
	'app_code'=>'tesis',
	'org_id'=>null,
	'org_code'=>null,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'tesis.local',
);