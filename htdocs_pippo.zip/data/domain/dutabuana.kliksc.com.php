<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>'107002',
	'org_code'=>'dutabuana.kliksc',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'dutabuana.kliksc.com',
);