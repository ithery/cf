<?php 
return array(
	'app_id'=>'990',
	'app_code'=>'adminlastmenit',
	'org_id'=>'1',
	'org_code'=>'lastmenit',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'admin.lastmenit.local',
	'shared_app_code'=>array(
            "lastmenitshare"
        ),
    
);