<?php 
return array(
	'app_id'=>'99',
	'app_code'=>'itdesk',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'itdesk.local',
);