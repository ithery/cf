<?php 
return array(
	'app_id'=>'891',
	'app_code'=>'adminittronmall',
	'org_id'=>'1',
	'org_code'=>'ittronmall',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'admin.ittronmall.local',
);