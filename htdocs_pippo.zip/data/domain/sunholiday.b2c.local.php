<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>17,
	'org_code'=>'sunholiday',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'sunholiday.b2c.local',
	'shared_app_code'=> array('cmstorsb2c'),
);