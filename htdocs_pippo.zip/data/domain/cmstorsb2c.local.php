<?php 
return array(
	'app_id'=>'405',
	'app_code'=>'cmstorsb2c',
	'org_id'=>'15',
	'org_code'=>'cmstorsb2c',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'cmstorsb2c.local',
);