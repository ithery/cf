<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>'15001',
	'org_code'=>'coba.demo.b2c.local',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'coba.demo.b2c.local',
);