<?php 
return array(
	'app_id'=>'888',
	'app_code'=>'namecard',
	'org_id'=>1,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'namecard.local',
        'shared_app_code'=>array(
            "adminnamecard"
        ),
);