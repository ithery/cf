<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'15',
	'org_code'=>'utamatour',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'utamatour.b2b.local',
);