<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'4',
	'org_code'=>'telindo',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'telindo.b2b.local',
);