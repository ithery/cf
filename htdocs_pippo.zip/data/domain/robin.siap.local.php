<?php

    return array(
	"app_id"=>'501',
	"app_code"=>"siap",
	"org_id"=>'5002',
	"org_code"=>'robin',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"robin.siap.local",
);
