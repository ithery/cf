<?php
return array (
	"description"=>"Specifies the main content of a document",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 