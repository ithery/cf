<?php
return array (
	"description"=>"Defines an article",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 