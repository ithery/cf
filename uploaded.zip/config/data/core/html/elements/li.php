<?php
return array (
	"description"=>"Defines a label for an <input> element",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"type"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies which kind of bullet point will be used"
		),
		"value"=>array(
			"html5"=>false,
			"html5_support"=>true,
			"description"=>"Specifies the value of a list item. The following list items will increment from that number (only for <ol> lists)"
		
		
		),
	),
	
); 