<?php
return array (
	"description"=>"Defines a set of frames",
	"html5"=>false,
	"html5_support"=>false,
	"attr"=>array(
		"cols"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the number and size of columns in a frameset"
		),
		"rows"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies a page that contains a long description of the content of a frame"
		
		
		
		),
	),
	
); 