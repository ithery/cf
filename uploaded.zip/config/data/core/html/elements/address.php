<?php
return array (
	"description"=>"Defines contact information for the author/owner of a document",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 