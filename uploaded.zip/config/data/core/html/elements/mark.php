<?php
return array (
	"description"=>"Defines marked/highlighted text",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 