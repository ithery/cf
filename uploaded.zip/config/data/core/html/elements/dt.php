dt<?php
return array (
	"description"=>"Defines a term/name in a description list",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 