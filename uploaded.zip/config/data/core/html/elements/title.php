<?php
return array (
	"description"=>"Defines a title for the document",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
	),
);	
		