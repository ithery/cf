<?php
return array (
	"description"=>"Defines a section in a document",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"align"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the alignment of the content inside a <div> element"
		
		),
		
	),
);	
		