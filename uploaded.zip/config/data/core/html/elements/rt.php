<?php
return array (
	"description"=>"Defines an explanation/pronunciation of characters (for East Asian typography)",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
	),
);	
		