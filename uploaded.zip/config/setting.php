<?php
//global config
$config["have_org"] = true;

//hardcode setting
$config["org_id"] = "";
$config["domain"] = "";
