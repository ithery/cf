<?php
return array(
	array(
		"name"=>"report_quotation",
		"label"=>"Quotation",
		"controller"=>"report_quotation",
		"method"=>"index",
		
	),
	
);