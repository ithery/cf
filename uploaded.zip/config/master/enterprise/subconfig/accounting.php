<?php

$accounting = array(
	
	array(
		"name"=>"have_accounting",
		"label"=>"Have Accounting",
		"default"=>false,
		"type"=>"checkbox",
		
	),
	
	
	
);