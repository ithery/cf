<?php

$production = array(
	array(
		"name"=>"have_production",
		"label"=>"Have Production",
		"default"=>false,
		"type"=>"checkbox",
	),
	
);