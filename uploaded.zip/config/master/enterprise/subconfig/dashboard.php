<?php

$dashboard = array(
	
	array(
		"name"=>"have_widget_transaction_count_graph",
		"label"=>"Transaction Count Graph Widget",
		"default"=>false,
		"type"=>"checkbox",
		
	),
	array(
		"name"=>"have_widget_transaction_amount_graph",
		"label"=>"Transaction Amount Graph Widget",
		"default"=>false,
		"type"=>"checkbox",
		
	),
	array(
        "name"=>"have_widget_sales_due_date_reminder",
        "label"=>"Sales Due Date Reminder Widget",
        "default"=>false,
        "type"=>"checkbox",

    ),
    array(
        "name"=>"have_widget_purchase_due_date_reminder",
        "label"=>"Purchase Due Date Reminder Widget",
        "default"=>false,
        "type"=>"checkbox",

    ),
    array(
        "name"=>"have_widget_sales_giro_reminder",
        "label"=>"Sales Giro Reminder Widget",
        "default"=>false,
        "type"=>"checkbox",
    ),
    array(
        "name"=>"have_widget_purchase_giro_reminder",
        "label"=>"Purchase Giro Reminder Widget",
        "default"=>false,
        "type"=>"checkbox",
    ),
);