<?php

$contact = array(
	array(
		"name"=>"have_contact_guest_group",
		"label"=>"Have Guest Group",
		"default"=>false,
		"type"=>"checkbox",
	),	
	array(
		"name"=>"have_contact_guest",
		"label"=>"Have Guest",
		"default"=>false,
		"type"=>"checkbox",
	),	
);