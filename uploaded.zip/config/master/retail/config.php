<?php
include dirname(__FILE__)."/subconfig/global.php";

$config=array(
	array(
		"name"=>"global_setting",
		"label"=>"Global",
		"config"=>$global,
	),
);


