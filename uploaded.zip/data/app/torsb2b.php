<?php 
return array(
	'app_id'=>'202',
	'code'=>'torsb2b',
	'name'=>'TORS B2B',
);