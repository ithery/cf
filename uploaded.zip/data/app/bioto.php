<?php 
return array(
	'app_id'=>'901',
	'code'=>'bioto',
	'name'=>'Bioto',
);