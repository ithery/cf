<?php 
return array(
	'app_id'=>'404',
	'code'=>'torsb2c',
	'name'=>'TORS B2C',
);