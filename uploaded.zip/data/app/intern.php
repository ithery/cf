<?php 
return array(
	'app_id'=>'9999',
	'code'=>'intern',
	'name'=>'Intern',
);