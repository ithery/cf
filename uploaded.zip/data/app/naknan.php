<?php 
return array(
	'app_id'=>'102',
	'code'=>'naknan',
	'name'=>'NAKNAN APPLICATION',
);