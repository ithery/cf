<?php 
return array(
	'app_id'=>'800',
	'code'=>'mobile62hallfamily',
	'name'=>'mobile 62Hall Family',
);