<?php 
return array(
	'app_id'=>'80',
	'code'=>'manual',
	'name'=>'MANUAL',
);