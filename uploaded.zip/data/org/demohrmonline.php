<?php

return array(
	"org_id"=>4001,
	"org_code"=>"demohrmonline",
	"org_name"=>"Demo HRM Online",
	
);

