<?php

return array(
	"org_id"=>4001,
	"org_code"=>"hrmonline",
	"org_name"=>"HRM Online",
	
);

