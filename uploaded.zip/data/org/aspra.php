<?php

return array(
	"org_id"=>'1001',
	"org_code"=>"aspra",
	"org_name"=>"ASPRA",
	
);

