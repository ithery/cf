<?php

return array(
	"org_id"=>14,
	"org_code"=>"tiketkarcis",
	"org_name"=>"TIKETKARCIS",
	
);

