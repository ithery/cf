<?php

return array(
	"org_id"=>1,
	"org_code"=>"kliktors",
	"org_name"=>"KLIKTORS",
	
);

