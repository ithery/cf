<?php 
return array(
	'app_id'=>'74',
	'app_code'=>'airlines',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'airlines.local',
);