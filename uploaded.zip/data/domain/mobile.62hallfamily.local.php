<?php 
return array(
	'app_id'=>'899',
	'app_code'=>'mobile62hallfamily',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'mobile.62hallfamily.local',
);