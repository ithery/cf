<?php
return array(
	"app_id"=>'200',
	"app_code"=>"enterprise",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"capp.local",
);
