<?php 
return array(
	'app_id'=>'901',
	'app_code'=>'bioto',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'bioto.local',
);