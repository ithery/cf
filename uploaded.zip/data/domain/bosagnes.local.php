<?php
return array(
	"app_id"=>'1',
	"app_code"=>"enterprise",
	"org_id"=>6001,
	"org_code"=>"bosagnes",
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"bosagnes.local",
);
