<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'8',
	'org_code'=>'pasopati',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'pasopati.b2b.local',
);