<?php
return array(
	"app_id"=>'1',
	"app_code"=>"enterprise",
	"org_id"=>6002,
	"org_code"=>"merahdelima",
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"merahdelima.local",
);
