<?php 
return array(
	'app_id'=>'890',
	'app_code'=>'admin62hallfamily',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'admin.62hallfamily.local',
);