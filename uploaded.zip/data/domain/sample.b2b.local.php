<?php 
return array(
	'app_id'=>'202',
	'app_code'=>'torsb2b',
	'org_id'=>'12',
	'org_code'=>'sample',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'sample.b2b.local',
);