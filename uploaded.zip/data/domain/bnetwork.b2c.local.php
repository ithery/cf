<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>15,
	'org_code'=>'bnetwork',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'bnetwork.b2c.local',
);