<?php 
return array(
	'app_id'=>'201',
	'app_code'=>'torsapi',
	'org_id'=>'62',
	'org_code'=>'62hall',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'62pay.local',
);