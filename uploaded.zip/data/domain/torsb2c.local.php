<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'torsb2c.local',
);