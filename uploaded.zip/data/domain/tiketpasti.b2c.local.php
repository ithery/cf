<?php 
return array(
	'app_id'=>'404',
	'app_code'=>'torsb2c',
	'shared_app_code'=> array('cmstorsb2c'),
	'org_id'=>16,
	'org_code'=>'tiketpasti',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'tiketpasti.b2c.local',
);