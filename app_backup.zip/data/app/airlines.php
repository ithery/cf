<?php 
return array(
	'app_id'=>'74',
	'code'=>'airlines',
	'name'=>'AIRLINES',
);