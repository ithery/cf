<?php 
return array(
	'app_id'=>'99',
	'code'=>'itdesk',
	'name'=>'IT DESK',
);