<?php 
return array(
	'app_id'=>'1001',
	'code'=>'bdc',
	'name'=>'BDC',
);