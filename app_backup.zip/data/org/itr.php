<?php

return array(
	"org_id"=>11,
	"org_code"=>"itr",
	"org_name"=>"ITR",
);