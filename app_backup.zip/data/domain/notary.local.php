<?php
return array(
	"app_id"=>'701',
	"app_code"=>"notary",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"notary.local",
);
