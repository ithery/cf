<?php 
return array(
	'app_id'=>'203',
	'app_code'=>'torsacc',
	'org_id'=>null,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'torsacc.local',
);