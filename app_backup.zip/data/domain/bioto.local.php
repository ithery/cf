<?php 
return array(
	'app_id'=>'901',
	'app_code'=>'bioto',
	'org_id'=>900002,
	'org_code'=>'bioto',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'bioto.local',
	'shared_app_code'=>array('biotoshare'),
);