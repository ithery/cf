<?php
return array(
	"app_id"=>'301',
	"app_code"=>"hrm",
	"org_id"=>'1004',
	"org_code"=>'devsuryagita',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"dev.suryagita.local",
);
