<?php
return array(
	"app_id"=>'2',
	"app_code"=>"resto",
	"org_id"=>'7777',
	"org_code"=>"development",
	"store_id"=>'71',
	"store_code"=>'resto01',
	"domain"=>"resto.local",
);
