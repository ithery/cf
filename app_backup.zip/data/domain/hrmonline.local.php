<?php
return array(
	"app_id"=>'401',
	"app_code"=>"hrmonline",
	"org_id"=>'4001',
	"org_code"=>'hrmonline',
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"hrmonline.local",
);
