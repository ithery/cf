<?php 
return array(
	'app_id'=>'204',
	'app_code'=>'tmsbayajaya',
	'org_id'=>NULL,
	'org_code'=>NULL,
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'tmsbayajaya.local',
);