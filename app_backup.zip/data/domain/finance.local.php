<?php
return array(
	"app_id"=>'702',
	"app_code"=>"finance",
	"org_id"=>null,
	"org_code"=>null,
	"store_id"=>null,
	"store_code"=>null,
	"domain"=>"finance.local",
);