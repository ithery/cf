<?php 
return array(
	'app_id'=>'900',
	'app_code'=>'adminbioto',
	'org_id'=>900002,
	'org_code'=>'bioto',
	'store_id'=>NULL,
	'store_code'=>NULL,
	'domain'=>'admin.bioto.local',
	'shared_app_code'=>array('biotoshare'),
);