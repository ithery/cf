<?php

return array(
	"store_id"=>'72',
	"store_code"=>"hotel01",
	"store_name"=>"Hotel 01",
	
);

