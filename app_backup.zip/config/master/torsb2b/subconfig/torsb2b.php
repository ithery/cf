<?php

return array(
	array(
		"name"=>"agent_label",
		"label"=>"Agent Label",
		"default"=>"Agent",
		"type"=>"text",
	),
	array(
		"name"=>"subagent_label",
		"label"=>"Subagent",
		"default"=>"Subagent",
		"type"=>"text",
	),
	
);