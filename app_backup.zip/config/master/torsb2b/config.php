<?php



$config= array(
	array(
		"name"=>"torsb2b_setting",
		"label"=>"B2B Setting",
		"config"=>include dirname(__FILE__)."/subconfig/torsb2b.php",
	),
	
	
);


