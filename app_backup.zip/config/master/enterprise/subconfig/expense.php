<?php

$expense = array(
	
	array(
		"name"=>"have_expense",
		"label"=>"Have Expense",
		"default"=>false,
		"type"=>"checkbox",
		"requirement"=>array(
		),
	),
);