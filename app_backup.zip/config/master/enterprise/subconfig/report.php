<?php

$report = array(
	
	array(
		"name"=>"report_stockcard_show_sales",
		"label"=>"Report Stockcard View Sales",
		"default"=>false,
		"type"=>"checkbox",
	),
	
	array(
		"name"=>"report_item_show_other_unit",
		"label"=>"Report Item Show Other Unit",
		"default"=>false,
		"type"=>"checkbox",
	),
	
	array(
		"name"=>"report_sales_show_cost",
		"label"=>"Report Sales Show Cost",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_report_xls",
		"label"=>"Have Xls",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_report_xls_xml",
		"label"=>"Have Xls Xml",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_report_csv",
		"label"=>"Have CSV",
		"default"=>false,
		"type"=>"checkbox",
	),
	array(
		"name"=>"have_report_pdf",
		"label"=>"Have PDF",
		"default"=>false,
		"type"=>"checkbox",
	),
	
);