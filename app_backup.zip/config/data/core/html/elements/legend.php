<?php
return array (
	"description"=>"Defines a caption for a <fieldset> element",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"align"=>array(
			"html5"=>false,
			"html5_support"=>false,
			"description"=>"Specifies the alignment of the caption"
		
		
		
		),
	),
	
); 