<?php
return array (
	"description"=>"Defines keyboard input",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 