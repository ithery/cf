<?php
return array (
	"description"=>"Defines an alternate content for users that do not support client-side scripts",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 