dt<?php
return array (
	"description"=>"Defines emphasized text ",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 