<?php
return array (
	"description"=>"Defines a date/time",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		"datetime"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Gives the date/time being specified. Otherwise, the date/time is given by the element's contents"
			
		),
	),
);	
		