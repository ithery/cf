<?php
return array (
	"description"=>"Defines a list/menu of commands",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		"label"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies a visible label for the menu"
		),
		"type"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies which type of menu to display"
		
		
		),
	),
	
); 