<?php
return array (
	"description"=>"Defines navigation links",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
				
		),
	
	
); 