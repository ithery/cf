<?php
return array (
	"description"=>"Defines a description/value of a term in a description list",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 