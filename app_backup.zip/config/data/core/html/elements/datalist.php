<?php
return array (
	"description"=>"Specifies a list of pre-defined options for input controls",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),
	
	
); 