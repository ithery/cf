<?php
return array (
	"description"=>"Defines what to show in browsers that do not support ruby annotations",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		
		
	),
);	
		