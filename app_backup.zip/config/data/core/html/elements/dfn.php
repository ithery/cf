<?php
return array (
	"description"=>"Defines a definition term",
	"html5"=>false,
	"html5_support"=>true,
	"attr"=>array(
		
		
		),

	
); 