<?php
return array (
	"description"=>"Defines additional details that the user can view or hide",
	"html5"=>true,
	"html5_support"=>true,
	"attr"=>array(
		"open"=>array(
			"html5"=>true,
			"html5_support"=>true,
			"description"=>"Specifies that the details should be visible (open) to the user"
		
		
		),
	),
	
); 